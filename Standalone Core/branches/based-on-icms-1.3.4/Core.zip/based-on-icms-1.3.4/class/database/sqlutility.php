<?php
/**
 * @copyright	http://www.impresscms.org/ The ImpressCMS Project
 * @license	http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License (GPL)
 * @package database
 * @subpackage  mysql
 * @since	ImpressCMS 1.1
 * @author      marcan <marcan@impresscms.org>
 * @author	The ImpressCMS Project
 * @version	$Id: sqlutility.php 10039 2010-06-16 22:16:40Z david-sf $
 */

/**
 * This file is deprecated. Including the real file and that's it.
 */
include_once ICMS_ROOT_PATH.'/class/database/drivers/'.XOOPS_DB_TYPE.'/sqlutility.php';
?>