<?php
/**
* FCK Editor version file
*
* @copyright	http://www.xoops.org/ The XOOPS Project
* @copyright	XOOPS_copyrights.txt
* @copyright	http://www.impresscms.org/ The ImpressCMS Project
* @license	LICENSE.txt
* @package	core
* @since	XOOPS
* @author	http://www.xoops.org The XOOPS Project
* @author	modified by UnderDog <underdog@impresscms.org>
* @version	$Id$
*/

$editorversion['name'] = "FCK WYSIWYG Editor";
$editorversion['version'] = 1.0;
$editorversion['license'] = "GPL see LICENSE";
$editorversion['dirname'] = "FCKeditor";

$editorversion['class'] = "XoopsFormFckeditor";
$editorversion['file'] = "formfckeditor.php";

?>