<?php
/**
 * FCKeditor adapter for XOOPS
 *
 * @copyright	The XOOPS project http://www.xoops.org/
 * @license		http://www.fsf.org/copyleft/gpl.html GNU public license
 * @author		Taiwen Jiang (phppp or D.J.) <php_pp@hotmail.com>
 * @since		4.00
 * @version		$Id: english.php 1800 2008-04-27 14:26:31Z xoops-magazine $
 * @package		xoopseditor
 */
/*
 * Assocated with editor_registry.php
 */
define("_XOOPS_EDITOR_DHTMLTEXTAREA", "DHTML Form with xCode");
?>